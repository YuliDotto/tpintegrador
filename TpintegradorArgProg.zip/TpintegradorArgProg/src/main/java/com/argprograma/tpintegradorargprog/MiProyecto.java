package com.argprograma.tpintegradorargprog;

import com.argprograma.tpintegradorargprog.Equipo;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class MiProyecto {

    public static void main(String[] args) throws IOException {
        
        List<Ronda> rondas = new ArrayList<>();
        List<Partido> partidos = new ArrayList<>();

        Path file1 = Paths.get("C:\\Users\\Martin\\Desktop\\curso arg programa\\TPIntegrador\\Resultados.csv");
        String file2 = ("C:\\Users\\Martin\\Desktop\\curso arg programa\\TPIntegrador\\Pronosticos.csv");
        
        
       Partido pt1 = new Partido();
       Equipo eq2 = new Equipo();
        Equipo eq1 = new Equipo();
        try {
            BufferedReader br = Files.newBufferedReader(file1);
            String linea;
            while ((linea = br.readLine()) != null) {

                StringTokenizer atributo = new StringTokenizer(linea, ";");


                while (atributo.hasMoreElements()) {

                    eq1.setNombre(atributo.nextElement().toString());
                    pt1.setGolesEquipo1(Integer.parseInt(atributo.nextElement().toString()));
                    pt1.setGolesEquipo2(Integer.parseInt(atributo.nextElement().toString()));
                    eq2.setNombre(atributo.nextElement().toString());

                }
                pt1.setEquipo1(eq1);
                pt1.setEquipo2(eq2);

                rondas.add(pt1);

                rondas.forEach(
                        c -> System.out.println(c));
                
                System.out.println("el resultado del equipo 1 es: ");
                pt1.calcularResultado(eq1);
                System.out.println("el resultado del equipo 2 es: ");
                pt1.calcularResultado(eq2);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        System.out.println("pronostico: ");
        
        for (String linea : Files.readAllLines(Paths.get(file2))){
            Pronostico pr1 = new Pronostico();
            pr1.setPartido(pt1);
             String[] detalle = linea.split(";");
             
             if(detalle[1].equalsIgnoreCase("x")){
                 System.out.println("usted eligio el equipo " + eq1 + " como ganador");
                 pr1.setEquipo(eq1);
                 pr1.setResultado(ResultadoEnum.GANADOR);
             }
             else if(detalle[2].equalsIgnoreCase("x")){
                 System.out.println("ustede eligio el empate");
                 pr1.setResultado(ResultadoEnum.EMPATE);
             }
             else if(detalle[3].equalsIgnoreCase("x")){
                 System.out.println("usted eligio el equipo " + eq2 + "como ganador");
                 pr1.setEquipo(eq2);
                 pr1.setResultado(ResultadoEnum.GANADOR);
             }
             
             pr1.calcularPronostico();
             
        }
        
        
        
        
        /*  //creamos la ronda 1 y un partido para agregar a la ronda
        Ronda r1 = new Ronda();

        //creamos los equipos 1 y 2
        Equipo eq1 = new Equipo("Argentina");
        Equipo eq2 = new Equipo("Arabia Saudita");

        Partido p1 = new Partido(eq1, eq2);

        //agregamos el partido a la ronda
        r1.agregarPartido(p1);
        //los agregamos al partido

        //agregamos los goles de cada equipo
        p1.setGolesEquipo1(1);
        p1.setGolesEquipo2(2);

        //definimos al ganador-perdedor-empate
        p1.calcularResultado(eq2);
        //creamos un pronostico
        
        Pronostico pr1 = new Pronostico(p1, eq1, ResultadoEnum.PERDEDOR);

        //calculamos el pronostico
        pr1.calcularPronostico();

         */
    }
}


