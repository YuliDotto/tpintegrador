package com.argprograma.tpintegradorargprog;

import java.util.ArrayList;
import java.util.List;

public class Ronda {

    private int numero;
    private List<Partido> partidos;

    public Ronda() {
        this.numero = ++numero;
        this.partidos = new ArrayList<Partido>();
    }

    public void agregarPartido(Partido p1) {
        this.partidos.add(p1);
    }

        
}
