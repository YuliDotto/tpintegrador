package com.argprograma.tpintegradorargprog;

public enum ResultadoEnum {
    GANADOR,
    PERDEDOR,
    EMPATE;
    
    
}
